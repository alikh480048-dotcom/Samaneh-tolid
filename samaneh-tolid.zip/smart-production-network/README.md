# شبکه هوشمند توسعه تولید و رفع موانع

پلتفرم B2B فارسی (RTL) با Next.js 14، Tailwind CSS، Prisma و PostgreSQL — شامل صفحه اصلی لوکس دارک-متالیک با نمودارهای تحلیلی و تیکر زنده.

## ✨ امکانات
- صفحه اصلی لوکس دارک-متالیک با آمار، ۲۱ ماژول، ویترین محصولات
- نمودارهای Recharts (معاملات استانی، فرصت‌های صادراتی، ظرفیت‌ها)
- تیکر اخبار لحظه‌ای
- مدل‌های داده: User, Product, Issue, IssueLog, Deal, Payment
- استقرار با Docker برای VPS یا Vercel

---

## 🚀 نصب روی سیستم شخصی (توسعه)

```bash
# 1) نصب Node.js 20+ و PostgreSQL
# 2) نصب وابستگی‌ها
npm install

# 3) تنظیم متغیرهای محیطی
cp .env.example .env
# فایل .env را ویرایش کنید و DATABASE_URL را ست کنید

# 4) ساخت دیتابیس و داده نمونه
npx prisma db push
npm run db:seed

# 5) اجرا
npm run dev
# → http://localhost:3000
```

---

## 🐳 استقرار روی VPS با Docker (روش پیشنهادی)

### پیش‌نیازها
- یک VPS (حداقل ۲GB RAM) با Ubuntu 22.04
- یک دامنه اشاره‌شده به IP سرور

### مراحل

```bash
# 1) نصب Docker و Docker Compose
curl -fsSL https://get.docker.com | sh
sudo apt install docker-compose-plugin -y

# 2) آپلود پروژه روی سرور
scp smart-production-network.zip user@SERVER_IP:/opt/
ssh user@SERVER_IP
cd /opt && unzip smart-production-network.zip && cd smart-production-network

# 3) اجرا
sudo docker compose up -d --build

# اپلیکیشن روی پورت 3000 اجرا می‌شود
```

### اتصال دامنه و SSL (Nginx + Certbot)

```bash
sudo apt install nginx certbot python3-certbot-nginx -y

# /etc/nginx/sites-available/spn
sudo tee /etc/nginx/sites-available/spn > /dev/null <<'EOF'
server {
    listen 80;
    server_name your-domain.com;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

sudo ln -s /etc/nginx/sites-available/spn /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# گواهی SSL رایگان
sudo certbot --nginx -d your-domain.com
```

سایت شما اکنون روی `https://your-domain.com` در دسترس است. ✅

### به‌روزرسانی
```bash
cd /opt/smart-production-network
git pull   # یا فایل جدید را آپلود کنید
sudo docker compose up -d --build
```

---

## ▲ استقرار روی Vercel

1. کد را در GitHub قرار دهید.
2. در [vercel.com](https://vercel.com) پروژه را Import کنید.
3. یک دیتابیس Postgres بسازید (مثلاً Vercel Postgres یا Neon) و `DATABASE_URL` را در Environment Variables ست کنید.
4. Deploy کنید. سپس به صورت محلی یک‌بار اجرا کنید:
   ```bash
   npx prisma db push
   npm run db:seed
   ```

---

## 🔑 متغیرهای محیطی

| متغیر | توضیح |
|---|---|
| `DATABASE_URL` | رشته اتصال PostgreSQL |
| `NEXT_PUBLIC_SITE_URL` | آدرس عمومی سایت |
| `NEXTAUTH_SECRET` | کلید رمزنگاری سشن‌ها |

## 📁 ساختار پروژه
```
src/app/            صفحه‌ها و layout
src/components/home/ MarketAnalytics و LiveTicker
prisma/             schema.prisma و seed.ts
Dockerfile          ایمیج پروडاکشن (standalone)
docker-compose.yml  اپ + PostgreSQL
```

## 🛠 عیب‌یابی
- خطای اتصال دیتابیس: مطمئن شوید کانتینر db سالم است: `docker compose ps`
- خطای Prisma: `npx prisma generate` را دوباره اجرا کنید.
