"use client";

import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip,
  PieChart, Pie, Cell, Legend, CartesianGrid,
} from "recharts";
import { TrendingUp } from "lucide-react";

const provincialData = [
  { province: "تهران", value: 543 },
  { province: "اصفهان", value: 467 },
  { province: "خوزستان", value: 389 },
  { province: "فارس", value: 312 },
  { province: "خراسان", value: 287 },
  { province: "تبریز", value: 241 },
];

const exportData = [
  { name: "آسیا", value: 45 },
  { name: "اروپا", value: 25 },
  { name: "آفریقا", value: 15 },
  { name: "خلیج فارس", value: 15 },
];

const capacityData = [
  { industry: "غذایی", pct: 72 },
  { industry: "معدنی", pct: 58 },
  { industry: "پتروشیمی", pct: 64 },
  { industry: "منسوجات", pct: 41 },
  { industry: "الکترونیک", pct: 53 },
];

const COLORS = ["#10b981", "#f4c95d", "#60a5fa", "#c084fc"];

export default function MarketAnalytics() {
  return (
    <section className="max-w-7xl mx-auto px-4 py-10">
      <div className="flex items-center gap-2 mb-6">
        <TrendingUp className="w-6 h-6 text-emerald-400" />
        <h2 className="text-2xl font-black">تحلیل بازار و داده‌های هوشمند</h2>
        <span className="text-emerald-400 text-sm font-bold mr-2">+۲۶٪ رشد</span>
      </div>
      <div className="grid lg:grid-cols-3 gap-5">
        <div className="card-glow rounded-2xl bg-white/5 p-5 lg:col-span-1">
          <h3 className="font-bold text-sm mb-4">حجم معاملات استانی</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={provincialData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="province" tick={{ fill: "#94a3b8", fontSize: 11 }} />
              <YAxis tick={{ fill: "#94a3b8", fontSize: 11 }} />
              <Tooltip contentStyle={{ background: "#1c2541", border: "1px solid #334155", borderRadius: 12 }} />
              <Bar dataKey="value" fill="#10b981" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card-glow rounded-2xl bg-white/5 p-5">
          <h3 className="font-bold text-sm mb-4">فرصت‌های صادراتی</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={exportData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3}>
                {exportData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ background: "#1c2541", border: "1px solid #334155", borderRadius: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="card-glow rounded-2xl bg-white/5 p-5">
          <h3 className="font-bold text-sm mb-4">ظرفیت‌های خالی کارخانجات</h3>
          <div className="space-y-4 mt-6">
            {capacityData.map((c) => (
              <div key={c.industry}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">{c.industry}</span>
                  <span className="text-amber-300 font-bold">{c.pct}٪</span>
                </div>
                <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full rounded-full bg-gradient-to-l from-emerald-500 to-emerald-300" style={{ width: `${c.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
