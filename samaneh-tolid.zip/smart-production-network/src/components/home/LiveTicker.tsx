"use client";

import { useEffect, useState } from "react";
import { Megaphone } from "lucide-react";

const items = [
  "🇮🇶 قرارداد صادرات پسته به عراق — ۲ ساعت پیش",
  "🇦🇪 ثبت سفارش عمده زعفران از امارات — ۴ ساعت پیش",
  "✅ رفع موفق مانع تأمین مواد اولیه پرونده ۱۴۰۳-۰۱۳۳۴۵",
  "🇹🇷 توافق‌نامه همکاری صادرات فرش با ترکیه — امروز",
  "🇩🇪 باز شدن مسیر صادرات قطعات صنعتی به آلمان — دیروز",
  "💰 پرداخت تسهیلات ۵۰ میلیاردی به واحدهای تولیدی کوچک",
];

export default function LiveTicker() {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIndex((i) => (i + 1) % items.length), 4000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="border-y border-white/10 bg-[#1c2541]/70">
      <div className="max-w-7xl mx-auto px-4 h-11 flex items-center gap-4 overflow-hidden">
        <span className="flex items-center gap-2 text-amber-300 text-xs font-bold whitespace-nowrap">
          <Megaphone className="w-4 h-4" /> اخبار لحظه‌ای
        </span>
        <div className="relative flex-1 h-6 overflow-hidden">
          {items.map((item, i) => (
            <p
              key={i}
              className={`absolute inset-0 text-xs text-slate-300 whitespace-nowrap transition-all duration-500 ${
                i === index ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3"
              }`}
            >
              {item}
            </p>
          ))}
        </div>
      </div>
    </div>
  );
}
