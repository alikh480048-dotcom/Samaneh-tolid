import Link from "next/link";
import {
  Factory, BarChart3, Globe2, ShieldCheck, Cpu, TrendingUp,
  Package, Users, FolderKanban, Coins, ArrowLeft,
} from "lucide-react";
import MarketAnalytics from "@/components/home/MarketAnalytics";
import LiveTicker from "@/components/home/LiveTicker";

const stats = [
  { icon: Coins, value: "۱۴.۸ میلیارد", label: "تومان درآمد کاربران" },
  { icon: Package, value: "۱,۳۶۰", label: "محصول در بازار" },
  { icon: FolderKanban, value: "۳۴۷", label: "پرونده فعال" },
  { icon: Users, value: "۴,۵۸۰", label: "کاربر فعال" },
];

const modules = [
  { icon: Factory, title: "ثبت و مدیریت واحدهای تولیدی", desc: "پروفایل کامل واحدها، ظرفیت‌ها و گواهی‌ها" },
  { icon: ShieldCheck, title: "شناسایی و ثبت موانع تولید", desc: "ثبت هوشمند موانع با کد رهگیری" },
  { icon: FolderKanban, title: "مدیریت پرونده‌ها و گردش کار", desc: "پیگیری مرحله‌به‌مرحله پرونده‌ها" },
  { icon: Users, title: "کارشناسان و مدیران جهادی", desc: "اتصال به شبکه کارشناسان سراسر کشور" },
  { icon: Package, title: "بازار و تجارت هوشمند", desc: "ویترین محصولات و سفارش عمده B2B" },
  { icon: Globe2, title: "صادرات و توسعه بازار", desc: "فرصت‌های صادراتی و بازارهای هدف" },
  { icon: Coins, title: "تسهیلات و منابع مالی", desc: "اتصال به بانک‌ها و صندوق‌های حمایی" },
  { icon: Cpu, title: "فناوری و نوآوری", desc: "داده‌کاوی و هوشمندسازی تصمیم‌ها" },
  { icon: BarChart3, title: "ارزیابی و پایش عملکرد", desc: "داشبوردهای تحلیلی و KPI ها" },
];

const products = [
  { title: "فرش دستباف ایرانی", tag: "آماده صادرات", loc: "اصفهان", price: "۴,۵۰۰,۰۰۰" },
  { title: "زعفران سوپر نگین", tag: "سفارش عمده", loc: "خراسان جنوبی", price: "۲,۶۵۰,۰۰۰" },
  { title: "پسته خام اکبری", tag: "آماده صادرات", loc: "کرمان", price: "۹۸۰,۰۰۰" },
  { title: "قطعات صنعتی دقیق", tag: "سفارش عمده سازمانی", loc: "تبریز", price: "تماس بگیرید" },
];

export default function HomePage() {
  return (
    <main className="min-h-screen metallic">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur border-b border-white/10 bg-[#0b132b]/80">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-400 to-emerald-700 flex items-center justify-center">
              <Factory className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-sm lg:text-base">شبکه هوشمند توسعه تولید و رفع موانع</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm text-slate-300">
            <Link href="/" className="hover:text-amber-300">خانه</Link>
            <Link href="/market" className="hover:text-amber-300">بازار</Link>
            <Link href="/issues/new" className="hover:text-amber-300">مانع تولید</Link>
            <Link href="/track" className="hover:text-amber-300">پیگیری</Link>
          </nav>
          <Link href="/login" className="text-sm border border-amber-400/40 text-amber-300 rounded-lg px-4 py-1.5 hover:bg-amber-400/10">
            ورود / ثبت‌نام
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 pt-16 pb-10 text-center">
        <p className="text-emerald-400 text-sm mb-3 tracking-wide">تولید، قدرت، اقتصاد ایران</p>
        <h1 className="text-3xl md:text-5xl font-black leading-tight gold-text">
          اتصال تولید ایرانی به بازارهای هدف و رفع هوشمند موانع
        </h1>
        <p className="mt-4 text-slate-300 max-w-2xl mx-auto">
          با هم موانع تولید را شناسایی کنیم، راهکار پیدا کنیم و بازارهای جدید بسازیم.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-4">
          <Link href="/issues/new" className="bg-emerald-500 hover:bg-emerald-400 text-white font-bold rounded-xl px-6 py-3 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5" /> ثبت مانع تولید
          </Link>
          <Link href="/market" className="border border-amber-400/50 text-amber-300 font-bold rounded-xl px-6 py-3 flex items-center gap-2 hover:bg-amber-400/10">
            <Package className="w-5 h-5" /> بازار و ویترین محصولات
          </Link>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s) => (
            <div key={s.label} className="card-glow rounded-2xl bg-white/5 p-5 flex items-center gap-4">
              <s.icon className="w-8 h-8 text-amber-300" />
              <div>
                <div className="text-xl font-black">{s.value}</div>
                <div className="text-xs text-slate-400">{s.label}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Analytics charts */}
      <MarketAnalytics />

      {/* Modules */}
      <section className="max-w-7xl mx-auto px-4 py-14">
        <h2 className="text-2xl font-black mb-2">۲۱ ماژول کلیدی شبکه هوشمند</h2>
        <p className="text-slate-400 mb-8">رفع موانع امروز، جهش تولید فردا</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {modules.map((m, i) => (
            <div key={i} className="card-glow rounded-2xl bg-white/5 p-6 hover:border-emerald-400/40 transition">
              <m.icon className="w-8 h-8 text-emerald-400 mb-3" />
              <h3 className="font-bold mb-1">{m.title}</h3>
              <p className="text-sm text-slate-400">{m.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Products */}
      <section className="max-w-7xl mx-auto px-4 pb-16">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black">نمایشگاه برگزیده تولیدات ایرانی</h2>
          <Link href="/market" className="text-emerald-400 text-sm flex items-center gap-1">
            مشاهده همه <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {products.map((p) => (
            <div key={p.title} className="card-glow rounded-2xl bg-white/5 overflow-hidden group">
              <div className="h-36 bg-gradient-to-br from-[#1c2541] to-[#0b132b] flex items-center justify-center">
                <Package className="w-10 h-10 text-slate-600 group-hover:text-emerald-500 transition" />
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-sm">{p.title}</h3>
                  <span className="text-[10px] bg-emerald-500/15 text-emerald-300 rounded-full px-2 py-0.5">{p.tag}</span>
                </div>
                <div className="mt-2 flex justify-between text-xs text-slate-400">
                  <span>{p.loc}</span>
                  <span className="text-amber-300 font-bold">{p.price} تومان</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Ticker + Footer */}
      <LiveTicker />
      <footer className="border-t border-white/10 py-8 text-center text-sm text-slate-500">
        <TrendingUp className="w-5 h-5 mx-auto mb-2 text-emerald-400" />
        شبکه هوشمند توسعه تولید و رفع موانع — با هم برای تولید و اشتغال پایدار
      </footer>
    </main>
  );
}
