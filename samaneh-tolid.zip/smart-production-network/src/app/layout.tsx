import type { Metadata } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";

const vazir = Vazirmatn({ subsets: ["arabic"], variable: "--font-vazir" });

export const metadata: Metadata = {
  title: "شبکه هوشمند توسعه تولید و رفع موانع",
  description: "پلتفرم B2B اتصال تولیدکنندگان ایرانی به بازارهای هدف و رفع هوشمند موانع تولید",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className={`${vazir.variable} font-sans bg-[#0b132b] text-slate-100 antialiased`}>
        {children}
      </body>
    </html>
  );
}
