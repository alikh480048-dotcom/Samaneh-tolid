import { PrismaClient, IssueStatus } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const admin = await prisma.user.upsert({
    where: { email: "admin@spn.ir" },
    update: {},
    create: {
      name: "مدیر سامانه",
      email: "admin@spn.ir",
      password: "$2a$10$CHANGE_ME_HASH", // با bcrypt هش کنید
      role: "ADMIN",
      province: "تهران",
      companyName: "شبکه هوشمند تولید",
    },
  });

  const producer = await prisma.user.create({
    data: {
      name: "تعاونی کشاورزی نمونه",
      email: "producer@spn.ir",
      password: "$2a$10$CHANGE_ME_HASH",
      role: "PRODUCER",
      province: "کرمان",
      companyName: "تعاونی کشاورزی نمونه",
    },
  });

  await prisma.product.createMany({
    data: [
      { title: "پسته خام", category: "خشکبار", province: "کرمان", price: 980000n, capacity: "۵ تن در ماه", exportReady: true, ownerId: producer.id },
      { title: "زعفران سرگل", category: "کشاورزی", province: "خراسان جنوبی", price: 2650000n, capacity: "۲۰۰ کیلوگرم در ماه", exportReady: true, ownerId: producer.id },
      { title: "فرش دستباف", category: "صنایع دستی", province: "اصفهان", price: 4500000n, exportReady: true, ownerId: producer.id },
      { title: "روغن زیتون", category: "غذایی", province: "گیلان", price: 780000n, exportReady: false, ownerId: producer.id },
    ],
  });

  const issue = await prisma.issue.create({
    data: {
      trackingCode: "1403-013345",
      title: "افزایش هزینه حمل و نقل",
      description: "مشکل در تأمین مواد اولیه و افزایش هزینه‌های حمل و نقل",
      category: "صنعتی",
      province: "تهران",
      status: IssueStatus.IN_PROGRESS,
      reporterId: producer.id,
    },
  });

  await prisma.issueLog.create({
    data: { message: "پرونده ثبت شد", status: IssueStatus.REGISTERED, issueId: issue.id },
  });

  console.log("✅ Seed completed");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
